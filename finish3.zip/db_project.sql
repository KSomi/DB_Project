-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- 생성 시간: 18-12-13 08:38
-- 서버 버전: 10.3.8-MariaDB
-- PHP 버전: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 데이터베이스: `db_project`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `admin`
--

CREATE TABLE `admin` (
  `ID` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `admin`
--

INSERT INTO `admin` (`ID`, `Password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- 테이블 구조 `client`
--

CREATE TABLE `client` (
  `ID` varchar(30) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Phone` int(12) DEFAULT NULL,
  `Rating` float DEFAULT NULL,
  `C_request_list` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `freelancer`
--

CREATE TABLE `freelancer` (
  `ID` varchar(30) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Phone` int(12) DEFAULT NULL,
  `Rating` float DEFAULT NULL,
  `Age` int(3) DEFAULT NULL,
  `Major` text DEFAULT NULL,
  `Career` int(3) DEFAULT NULL,
  `F_request_list` text DEFAULT NULL,
  `exp` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `message`
--

CREATE TABLE `message` (
  `Time` timestamp NOT NULL DEFAULT current_timestamp(),
  `C_id` varchar(30) NOT NULL,
  `F_id` varchar(30) NOT NULL,
  `Text` text DEFAULT NULL,
  `Mnum` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `portfolio`
--

CREATE TABLE `portfolio` (
  `P_fid` varchar(30) NOT NULL,
  `num` int(3) NOT NULL,
  `Out` tinyint(1) NOT NULL,
  `P_Num` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `proficiency`
--

CREATE TABLE `proficiency` (
  `ID` varchar(30) NOT NULL,
  `Pro_c` int(10) DEFAULT NULL,
  `Pro_j` int(10) DEFAULT NULL,
  `Pro_js` int(10) DEFAULT NULL,
  `Pro_p` int(10) DEFAULT NULL,
  `Pro_e` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `request`
--

CREATE TABLE `request` (
  `NUM` int(30) NOT NULL,
  `Upload_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `C_id` varchar(30) NOT NULL,
  `Budget` int(10) DEFAULT NULL,
  `Start_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `End_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `Pro_c` int(3) DEFAULT NULL,
  `Pro_j` int(3) DEFAULT NULL,
  `Pro_js` int(3) DEFAULT NULL,
  `Pro_p` int(3) DEFAULT NULL,
  `Pro_e` int(3) DEFAULT NULL,
  `Minimum_career` int(3) DEFAULT NULL,
  `Min_num_person` int(5) DEFAULT NULL,
  `Max_num_person` int(5) DEFAULT NULL,
  `Accepted` varchar(30) DEFAULT '0',
  `Accept_f` varchar(30) DEFAULT NULL,
  `Accept_t` varchar(30) DEFAULT NULL,
  `Complete` int(3) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `team`
--

CREATE TABLE `team` (
  `Name` varchar(30) NOT NULL,
  `Leader` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `teammate`
--

CREATE TABLE `teammate` (
  `Teamname` varchar(30) NOT NULL,
  `Teammate` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- 테이블의 인덱스 `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`ID`);

--
-- 테이블의 인덱스 `freelancer`
--
ALTER TABLE `freelancer`
  ADD PRIMARY KEY (`ID`);

--
-- 테이블의 인덱스 `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`Mnum`),
  ADD KEY `mcid` (`C_id`),
  ADD KEY `mfid` (`F_id`);

--
-- 테이블의 인덱스 `portfolio`
--
ALTER TABLE `portfolio`
  ADD PRIMARY KEY (`P_Num`),
  ADD KEY `pfid` (`P_fid`);

--
-- 테이블의 인덱스 `proficiency`
--
ALTER TABLE `proficiency`
  ADD KEY `freelancerid` (`ID`);

--
-- 테이블의 인덱스 `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`NUM`),
  ADD KEY `client_id` (`C_id`),
  ADD KEY `accept_f` (`Accept_f`),
  ADD KEY `team_name` (`Accept_t`);

--
-- 테이블의 인덱스 `team`
--
ALTER TABLE `team`
  ADD PRIMARY KEY (`Name`),
  ADD KEY `t_leader` (`Leader`);

--
-- 테이블의 인덱스 `teammate`
--
ALTER TABLE `teammate`
  ADD KEY `teamname` (`Teamname`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `message`
--
ALTER TABLE `message`
  MODIFY `Mnum` int(30) NOT NULL AUTO_INCREMENT;

--
-- 테이블의 AUTO_INCREMENT `portfolio`
--
ALTER TABLE `portfolio`
  MODIFY `P_Num` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- 테이블의 AUTO_INCREMENT `request`
--
ALTER TABLE `request`
  MODIFY `NUM` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 덤프된 테이블의 제약사항
--

--
-- 테이블의 제약사항 `message`
--
ALTER TABLE `message`
  ADD CONSTRAINT `mcid` FOREIGN KEY (`C_id`) REFERENCES `client` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `mfid` FOREIGN KEY (`F_id`) REFERENCES `freelancer` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 테이블의 제약사항 `portfolio`
--
ALTER TABLE `portfolio`
  ADD CONSTRAINT `pfid` FOREIGN KEY (`P_fid`) REFERENCES `freelancer` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 테이블의 제약사항 `proficiency`
--
ALTER TABLE `proficiency`
  ADD CONSTRAINT `freelancerid` FOREIGN KEY (`ID`) REFERENCES `freelancer` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 테이블의 제약사항 `request`
--
ALTER TABLE `request`
  ADD CONSTRAINT `accept_f` FOREIGN KEY (`Accept_f`) REFERENCES `freelancer` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `client_id` FOREIGN KEY (`C_id`) REFERENCES `client` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `team_name` FOREIGN KEY (`Accept_t`) REFERENCES `team` (`Name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 테이블의 제약사항 `team`
--
ALTER TABLE `team`
  ADD CONSTRAINT `t_leader` FOREIGN KEY (`Leader`) REFERENCES `freelancer` (`ID`) ON DELETE CASCADE;

--
-- 테이블의 제약사항 `teammate`
--
ALTER TABLE `teammate`
  ADD CONSTRAINT `teamname` FOREIGN KEY (`Teamname`) REFERENCES `team` (`Name`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
