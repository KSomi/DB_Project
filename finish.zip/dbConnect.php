<?php
$host = 'localhost';
$user = 'root';
$pw = 'autoset';
$dbName = 'db_project';

$dbConnect = new mysqli($host, $user, $pw, $dbName);
?>
